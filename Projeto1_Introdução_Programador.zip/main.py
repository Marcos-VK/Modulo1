print("Hello CodeSandbox!")
def funcao(x):
    y=x**2+x*2+16
    return y

print("y=x**2+x*2+16")
valorX=int(input("Digite um numero inteiro para X: "))
print(funcao(valorX))